def outflies(sum_up, difference, product, quotient):
    print("Sum:"  sum_up)
    print("difference:"  +str(difference))
    print("product:"  +str(product))
    print("Quotient:" +str(quotient))