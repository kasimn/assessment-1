def inputfiles():
    num_1 = float(input("Enter the first number:"))
    num_2 = float(input("Enter the second number:"))
    return num_1, num_2